Move the entire contents of this folder to a directory on your web server.

The files served as part of your timeline are static resources so they work well with global edge networks such as Amazon's S3 / Cloudfront service.

Please note that the page may not render correctly when viewed on the local file system due to the default WebGL security settings in the browser (which may not allow scripts to access local files). It will work properly when served through web server.
